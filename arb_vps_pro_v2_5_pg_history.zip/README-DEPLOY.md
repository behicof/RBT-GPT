# راهنمای استقرار روی VPS (نسخه Pro v2.1)

این راهنما خلاصه‌ی مراحل لازم برای راه‌اندازی سریع سیستم آربیتراژ روی VPS است. (نسخه‌ای که همراه این پروژه منتشر شده)
- Docker 24+ و Compose لازم است.
- همه سرویس‌ها با `docker compose up -d` بالا می‌آیند.
- برای اجرای واقعی، ابتدا با Dry-run پایش کن، سپس LIVE_MODE را روشن کن.

## گام‌ها
1) فایل `.env.example` را کپی کن به `.env` و مقادیر را پر کن (توکن‌ها/کلیدها).
2) آستانه‌ها را در `configs/markets.yaml` و `configs/risk.yml` تنظیم کن.
3) بیلد و اجرا:
```bash
docker compose build
docker compose up -d
```
4) سلامت و متریک‌ها:
```bash
curl -s http://localhost:8080/health
curl -s http://localhost:8080/metrics | head
```
5) ورود به Grafana: `http://<IP>:3000` (admin/admin) — داشبورد به‌صورت خودکار Provision می‌شود.
6) وقتی KPIها پایدار شد، `LIVE_MODE=1` و آداپتر مناسب را انتخاب کن (مثلاً `EXEC_ADAPTER=nobitex`).

## نکات ایمنی
- اندازه پوزیشن را کوچک نگه دار (`risk.yml`).
- Circuit breakerها را سخت‌گیرانه تنظیم کن.
- اسرار را در `.env` نگه دار، نه در گیت.


## ذخیرهٔ تریدها در Postgres
- جدول: `trades` به‌صورت خودکار ساخته می‌شود.
- لیست تریدها: `GET /trades?limit=100`
- خروجی CSV: `GET /trades.csv?limit=1000`
- گرافانا دارای دیتاسورس Postgres و پنل "Recent Trades (DB)" است.
