#!/usr/bin/env bash
set -euo pipefail
API_URL="${API_URL:-http://localhost:8080}"
XKEY="${XKEY:-}"

echo "[1/2] POST /execute/dual (MEXC buy → COINEX sell)"
curl -s -X POST "$API_URL/execute/dual"       -H "Content-Type: application/json"       -H "X-API-KEY: $XKEY"       -d '{
    "symbol":"ETHUSDT",
    "qty": 0.01,
    "legs":[
      {"venue":"mexc","side":"buy","tif":"IOC"},
      {"venue":"coinex","side":"sell","tif":"IOC"}
    ],
    "offset_bps": 8
  }' | jq . || true

echo "[2/2] GET /metrics (head)"
curl -s "$API_URL/metrics" | head
