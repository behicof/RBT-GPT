# VPS Arbitrage – Production Starter (v1.0)

This is a minimal, production‑minded starter for a low‑latency arbitrage system:
Collector → Redis → Analyzer → Executor → API, with Postgres/Grafana/Prometheus via Docker Compose.

**First run (dry‑run)**:
1) Copy `.env.example` to `.env` and fill tokens/URLs.
2) Edit `configs/markets.yaml` and `configs/risk.yml` thresholds.
3) `docker compose up -d` (Docker 24+ recommended).
4) Dry‑run: signals will be produced but no real orders placed.
5) Switch to live only after reviewing KPIs (latency/fill ratio) in Grafana.

> NOTE: Exchange clients for non‑public/private endpoints are placeholders.
> Integrations should be filled with your keys and tested with tiny sizes.


## Live Mode (toggle)
- Set `LIVE_MODE=1` and `EXEC_ADAPTER=nobitex` (or `paper`) in `.env`.
- Provide `NOBITEX_TOKEN` in `.env`.
- **Warning**: The `NobitexAdapter` is a template. Verify endpoints/params with official docs and test with tiny sizes first.

## Backtest
`python backtest/replay.py --path path/to/orderbooks.jsonl --qty 100`


## Pro v2 Enhancements
- Redis lock for atomic dual-leg to avoid race/duplication
- Hedge-on-fail fallback and configurable timeouts/offsets
- Prometheus `/metrics` endpoint in API; Grafana autoprovisioned
- Risk-aware position sizing from `risk.yml`
