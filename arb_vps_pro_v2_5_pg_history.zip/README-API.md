# API – نقطه‌های کلیدی

## POST /execute
سیگنال اجرای فوری یک معامله‌ی دو لِگ (در حال حاضر توسط Executor و تک آداپتر فعال انجام می‌شود).

### بدنه درخواست (JSON)
```json
{
  "pair": "USDT-IRT",
  "buy": 610000,
  "sell": 612500,
  "qty": 100
}
```
- `pair`: جفت‌ارز، مثال: `USDT-IRT`
- `buy`: قیمت خرید
- `sell`: قیمت فروش
- `qty`: مقدار (مثلاً تعداد USDT)

### رفتار
- API پیام را در کانال Redis با الگوی `sig:<pair>` منتشر می‌کند.
- Executor مشترک الگوی `sig:*` است و پس از دریافت، با توجه به `routing_policy.py` دو لِگ را اجرا می‌کند.

### پاسخ نمونه
```json
{
  "ok": true,
  "published": "sig:USDT-IRT",
  "payload": { "pair":"USDT-IRT", "buy":610000, "sell":612500, "qty":100 }
}
```

## GET /health
سلامت سرویس.

## GET /metrics
متریک‌های Prometheus.


---

## POST /execute/dual
اجرای دو لِگ روی دو صرافی یا دو مسیر متفاوت.

### بدنه درخواست
```json
{
  "symbol": "ETHUSDT",
  "qty": 0.01,
  "legs": [
    {"venue":"mexc","side":"buy","tif":"IOC"},
    {"venue":"coinex","side":"sell","tif":"IOC"}
  ],
  "offset_bps": 8
}
```
- اگر لِگ دوم در مدت `SECOND_LEG_TIMEOUT_MS` انجام نشد، در صورت فعال بودن `HEDGE_ON_FAIL`، هِج ساده روی لِگ اول انجام می‌شود.
