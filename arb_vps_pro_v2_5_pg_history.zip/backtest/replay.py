import json, argparse, math, time, random, statistics
from pathlib import Path

def vwap(asks, bids, qty):
    # simplistic vwap fill estimator using asks for buys and bids for sells
    filled = 0.0
    cost = 0.0
    for p, q in asks:
        take = min(qty - filled, q)
        cost += take * p
        filled += take
        if filled >= qty:
            break
    if filled < qty:
        return None
    return cost / qty

def simulate_from_jsonl(path, qty=100.0):
    asks = None; bids = None
    pnl_list = []
    for line in Path(path).read_text().splitlines():
        ob = json.loads(line)["data"]["orderbook"]
        asks = [(float(p), float(q)) for p, q in ob.get("asks", [])]
        bids = [(float(p), float(q)) for p, q in ob.get("bids", [])]
        if not asks or not bids:
            continue
        buy_px = vwap(asks, bids, qty)
        sell_px = vwap(bids, asks, qty)  # reverse
        if buy_px and sell_px:
            pnl = (sell_px - buy_px) / buy_px
            pnl_list.append(pnl)
    return {
        "trades": len(pnl_list),
        "mean_pnl": statistics.mean(pnl_list) if pnl_list else 0.0,
        "p50": statistics.median(pnl_list) if pnl_list else 0.0,
        "p95": sorted(pnl_list)[int(0.95*len(pnl_list))-1] if pnl_list else 0.0
    }

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--path", required=True, help="Path to JSONL orderbook stream")
    ap.add_argument("--qty", type=float, default=100.0)
    args = ap.parse_args()
    res = simulate_from_jsonl(args.path, qty=args.qty)
    print(json.dumps(res, indent=2))
