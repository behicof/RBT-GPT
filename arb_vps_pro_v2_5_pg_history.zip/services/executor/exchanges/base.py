from typing import Any, Dict

class ExecutionAdapter:
    """
    Abstract execution adapter interface.
    Implement place_order, cancel_order, get_balance, get_positions as needed.
    """
    name = "base"

    async def place_order(self, symbol: str, side: str, qty: float, order_type: str = "market", price: float | None = None) -> Dict[str, Any]:
        raise NotImplementedError

    async def cancel_order(self, order_id: str) -> Dict[str, Any]:
        raise NotImplementedError

    async def get_balance(self) -> Dict[str, Any]:
        raise NotImplementedError

    async def get_positions(self) -> Dict[str, Any]:
        return {}
