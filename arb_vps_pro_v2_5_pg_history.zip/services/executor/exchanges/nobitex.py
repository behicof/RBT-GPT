import os, aiohttp, time
from typing import Any, Dict
from .base import ExecutionAdapter

class NobitexAdapter(ExecutionAdapter):
    """
    Template adapter for Nobitex private REST.
    You must provide a valid API token via env: NOBITEX_TOKEN.
    Endpoints/fields should be verified against official docs before enabling live orders.
    """
    name = "nobitex"
    def __init__(self, base_url: str = "https://apiv2.nobitex.ir"):
        self.base_url = base_url
        self.token = os.getenv("NOBITEX_TOKEN", "")

    async def _auth_headers(self) -> Dict[str, str]:
        if not self.token:
            raise RuntimeError("NOBITEX_TOKEN is not set")
        return {"Authorization": f"Token {self.token}"}

    async def place_order(self, symbol: str, side: str, qty: float, order_type: str = "market", price: float | None = None) -> Dict[str, Any]:
        # WARNING: This is a template; verify endpoint and payload.
        # Example payload shape only.
        async with aiohttp.ClientSession() as s:
            url = f"{self.base_url}/market/orders/add"
            payload = {
                "type": order_type,
                "srcCurrency": symbol.split('/')[0].lower(),
                "dstCurrency": symbol.split('/')[1].lower(),
                "side": side.lower(),   # 'buy' or 'sell'
                "amount": str(qty),
            }
            if price is not None:
                payload["price"] = str(price)
            r = await s.post(url, headers=await self._auth_headers(), data=payload, timeout=5)
            r.raise_for_status()
            return await r.json()

    async def cancel_order(self, order_id: str) -> Dict[str, Any]:
        async with aiohttp.ClientSession() as s:
            url = f"{self.base_url}/market/orders/cancel"
            payload = {"id": order_id}
            r = await s.post(url, headers=await self._auth_headers(), data=payload, timeout=5)
            r.raise_for_status()
            return await r.json()

    async def get_balance(self) -> Dict[str, Any]:
        async with aiohttp.ClientSession() as s:
            url = f"{self.base_url}/users/wallets/list"
            r = await s.get(url, headers=await self._auth_headers(), timeout=5)
            r.raise_for_status()
            return await r.json()
