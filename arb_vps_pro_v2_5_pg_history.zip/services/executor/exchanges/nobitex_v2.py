import os, requests

class NobitexAdapter:
    BASE = os.getenv("NOBITEX_BASE","https://api.nobitex.ir")
    TOKEN= os.getenv("NOBITEX_TOKEN","")
    UA   = os.getenv("USER_AGENT","TraderBot/UltraOpt")
    TIMEOUT = float(os.getenv("NOBITEX_TIMEOUT","6.0"))

    def _headers(self):
        return {"Authorization": f"Token {self.TOKEN}", "Content-Type":"application/json", "User-Agent": self.UA}

    @staticmethod
    def _map_dst(dst):  # IRT→rls
        return "rls" if dst.lower() in ("irt","rial","rls") else dst.lower()

    def orderbook(self, symbol: str):
        r = requests.get(f"{self.BASE}/v3/orderbook/{symbol}", timeout=self.TIMEOUT, headers={"User-Agent": self.UA})
        r.raise_for_status()
        return r.json()

    def place_order(self, srcCurrency, dstCurrency, side, amount, price=None):
        payload = {
            "type": side.lower(),
            "srcCurrency": srcCurrency.lower(),
            "dstCurrency": self._map_dst(dstCurrency),
            "amount": str(amount),
            "execution": "limit" if price is not None else "market",
        }
        if price is not None: payload["price"] = str(price)
        r = requests.post(f"{self.BASE}/market/orders/add", json=payload, headers=self._headers(), timeout=self.TIMEOUT)
        r.raise_for_status()
        return r.json()

    def cancel_update_status(self, order_id: str, new_status="canceled"):
        payload = {"orderId": order_id, "status": new_status}
        r = requests.post(f"{self.BASE}/market/orders/update-status", json=payload, headers=self._headers(), timeout=self.TIMEOUT)
        r.raise_for_status()
        return r.json()
