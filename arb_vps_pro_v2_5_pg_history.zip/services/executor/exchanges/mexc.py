import os, time, hmac, hashlib, requests
from urllib.parse import urlencode

class MexcAdapter:
    BASE = os.getenv("MEXC_BASE","https://api.mexc.com")
    KEY  = os.getenv("MEXC_KEY","")
    SEC  = os.getenv("MEXC_SECRET","")
    TIMEOUT = float(os.getenv("MEXC_TIMEOUT","6.0"))

    def _ts(self): return str(int(time.time()*1000))
    def _headers(self): return {"X-MEXC-APIKEY": self.KEY}

    def _sign(self, params: dict) -> str:
        q = urlencode([(k, params[k]) for k in sorted(params.keys())])
        return hmac.new(self.SEC.encode(), q.encode(), hashlib.sha256).hexdigest()

    def place_order(self, symbol, side, qty, price=None, tif="IOC"):
        params = {
            "symbol": symbol,
            "side": side.upper(),
            "type": "LIMIT" if price is not None else "MARKET",
            "quantity": str(qty),
            "timestamp": self._ts(),
            "recvWindow": "5000"
        }
        if price is not None:
            params["price"] = str(price)
            params["timeInForce"] = tif  # IOC|FOK|GTC
        params["signature"] = self._sign(params)
        r = requests.post(f"{self.BASE}/api/v3/order", params=params, headers=self._headers(), timeout=self.TIMEOUT)
        r.raise_for_status()
        return r.json()

    def cancel(self, symbol, order_id=None, client_id=None):
        params = {"symbol": symbol, "timestamp": self._ts(), "recvWindow":"5000"}
        if order_id: params["orderId"] = str(order_id)
        if client_id: params["origClientOrderId"] = client_id
        params["signature"] = self._sign(params)
        r = requests.delete(f"{self.BASE}/api/v3/order", params=params, headers=self._headers(), timeout=self.TIMEOUT)
        r.raise_for_status()
        return r.json()
