import time, uuid
from typing import Any, Dict
from .base import ExecutionAdapter

class PaperAdapter(ExecutionAdapter):
    name = "paper"

    async def place_order(self, symbol: str, side: str, qty: float, order_type: str = "market", price: float | None = None) -> Dict[str, Any]:
        oid = str(uuid.uuid4())
        return {
            "order_id": oid,
            "status": "filled",
            "filled_qty": qty,
            "avg_price": price if price else 0.0,
            "ts": int(time.time() * 1000),
        }

    async def cancel_order(self, order_id: str) -> Dict[str, Any]:
        return {"order_id": order_id, "status": "canceled"}

    async def get_balance(self) -> Dict[str, Any]:
        return {"USDT": 100000.0, "IRT": 0.0}
