import os, time, hmac, hashlib, json, requests

class CoinexAdapter:
    BASE = os.getenv("COINEX_BASE","https://api.coinex.com/v2")
    KEY  = os.getenv("COINEX_KEY","")
    SEC  = os.getenv("COINEX_SECRET","")
    TIMEOUT = float(os.getenv("COINEX_TIMEOUT","6.0"))

    def _ts(self): return str(int(time.time()*1000))

    def _sign(self, method: str, path: str, body: dict|None, ts: str) -> str:
        raw = method + path + (json.dumps(body, separators=(",",":")) if body else "") + ts
        return hmac.new(self.SEC.encode(), raw.encode(), hashlib.sha256).hexdigest()

    def _headers(self, sig: str, ts: str):
        return {
            "X-COINEX-KEY": self.KEY,
            "X-COINEX-SIGN": sig,
            "X-COINEX-TIMESTAMP": ts,
            "Content-Type": "application/json"
        }

    def place_order(self, symbol, side, qty, price=None, tif="ioc"):
        typ = "limit" if price is not None else "market"
        if price is not None and tif in ("ioc","fok"): typ = tif
        body = {
            "market": symbol,
            "market_type": "SPOT",
            "side": side.lower(),
            "type": typ,
            "amount": str(qty)
        }
        if price is not None:
            body["price"] = str(price)
        path = "/v2/spot/order"
        ts = self._ts()
        sig = self._sign("POST", path, body, ts)
        r = requests.post(self.BASE + path, headers=self._headers(sig, ts), data=json.dumps(body), timeout=self.TIMEOUT)
        r.raise_for_status()
        return r.json()

    def cancel(self, symbol, order_id: str):
        body = {"market": symbol, "market_type":"SPOT", "order_id": str(order_id)}
        path = "/v2/spot/cancel-order"
        ts = self._ts()
        sig = self._sign("POST", path, body, ts)
        r = requests.post(self.BASE + path, headers=self._headers(sig, ts), data=json.dumps(body), timeout=self.TIMEOUT)
        r.raise_for_status()
        return r.json()
