import os, asyncio, json, time, uuid
import redis.asyncio as aioredis
import yaml
import asyncpg
import yaml, asyncio, math

LOCK_TTL_MS = int(os.getenv("LOCK_TTL_MS", "1000"))
SECOND_LEG_TIMEOUT_MS = int(os.getenv("SECOND_LEG_TIMEOUT_MS", "800"))
HEDGE_ON_FAIL = os.getenv("HEDGE_ON_FAIL", "1") == "1"
RETRY_MAX = int(os.getenv("SECOND_LEG_RETRY_MAX", "2"))
RETRY_BASE_MS = int(os.getenv("SECOND_LEG_RETRY_BASE_MS", "150"))
SECOND_LEG_OFFSET_BPS = float(os.getenv("SECOND_LEG_OFFSET_BPS", "5.0"))  # 5 bps default for limit offset

async def acquire_lock(r, key: str, ttl_ms: int) -> bool:
    # Simple NX PX lock
    return await r.set(key, "1", nx=True, px=ttl_ms)

async def release_lock(r, key: str):
    try:
        await r.delete(key)
    except Exception:
        pass

async def place_second_leg(adapter, symbol: str, side: str, qty: float, ref_price: float | None = None):
    # If we had a ref price, add/subtract bps offset for a protective limit;
    # for now use market if no price is known (template adapters support market safely).
    # In a real integration, fetch best bid/ask from cache to compute limit price.
    if ref_price:
        if side.lower() == "sell":
            px = ref_price * (1 - SECOND_LEG_OFFSET_BPS/10000.0)
        else:
            px = ref_price * (1 + SECOND_LEG_OFFSET_BPS/10000.0)
        return await adapter.place_order(symbol, side, qty, order_type="limit", price=px)
    return await adapter.place_order(symbol, side, qty, order_type="market")


def _load_risk_cfg(path: str):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    except Exception:
        return {}

def _position_size(symbol: str, risk_cfg: dict, price_hint: float | None = None):
    # Simplified: use max_notional_per_trade; if price hint exists, convert to qty
    max_notional = float(risk_cfg.get("position_sizing", {}).get("max_notional_per_trade", 2000))
    if price_hint and price_hint > 0:
        qty = max(0.0001, max_notional / price_hint)
    else:
        # fallback qty
        qty = 1.0
    return qty

async def atomic_dual_leg(adapter, symbol: str, buy_first: bool, qty: float, timeout_ms: int = 800):
    async def _buy():
        return await adapter.place_order(symbol, "buy", qty, order_type="market")
    async def _sell():
        return await adapter.place_order(symbol, "sell", qty, order_type="market")

    async def _do():
        if buy_first:
            res1 = await _buy()
            res2 = await _sell()
        else:
            res1 = await _sell()
            res2 = await _buy()
        return {"leg1": res1, "leg2": res2}

    try:
        return await asyncio.wait_for(_do(), timeout=timeout_ms/1000)
    except asyncio.TimeoutError:
        return {"error": "timeout"}


REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
RISK_CFG = os.getenv("RISK_CFG", "./configs/risk.yml")
PG_URL = os.getenv("PG_URL", "postgresql://postgres:arbpass@localhost:5432/arbdb")

DDL = """
CREATE TABLE IF NOT EXISTS trades_log (
  id TEXT PRIMARY KEY,
  ts BIGINT,
  symbol TEXT,
  buy_venue TEXT,
  sell_venue TEXT,
  gross DOUBLE PRECISION,
  status TEXT,
  details JSONB
);
"""

async def init_db():
  conn = await asyncpg.connect(PG_URL)
  await conn.execute(DDL)
  await conn.close()


import importlib
LIVE_MODE = os.getenv("LIVE_MODE", "0") == "1"
EXEC_ADAPTER = os.getenv("EXEC_ADAPTER", "paper")  # 'paper' or 'nobitex'

def load_adapter():
    if EXEC_ADAPTER == "nobitex":
        mod = importlib.import_module("exchanges.nobitex")
        return mod.NobitexAdapter()
    else:
        mod = importlib.import_module("exchanges.paper")
        return mod.PaperAdapter()


async def run():
    global DB_POOL

    await init_db()
    pool = await asyncpg.create_pool(PG_URL, min_size=1, max_size=3)
    r = aioredis.from_url(REDIS_URL, decode_responses=True)
    # dry-run: listen to signals stream and log to DB
    last_id = "0-0"
    while True:
        streams = await r.xread({"signals": last_id}, block=2000, count=50)
        if not streams:
            continue
        for stream_name, entries in streams:
            for entry_id, kv in entries:
                last_id = entry_id
                data = json.loads(kv["data"])
                # place real orders here (TODO)
                adapter = load_adapter()
                if LIVE_MODE:
                    # example: market order both legs (you must verify symbols and volume units)
                    # This is a simplified example; production must include fees/slippage calc
                    risk_cfg = _load_risk_cfg(os.getenv("RISK_CFG", "./configs/risk.yml"))
                    qty = _position_size(data["symbol"], risk_cfg)
                    
# Acquire symbol lock to avoid concurrent double-fires
lock_key = f"arb:lock:{data['symbol']}"
locked = await r.set(lock_key, "1", nx=True, px=LOCK_TTL_MS)
if not locked:
    status = "LOCKED_SKIP"
    details = {"reason": "lock contention", "received": int(time.time()*1000)}
else:
    try:
        both = await atomic_dual_leg(adapter, data["symbol"], buy_first=True, qty=qty, timeout_ms=SECOND_LEG_TIMEOUT_MS)
        status = "LIVE_SENT" if "error" not in both else "TIMEOUT"
        details = {"exec": both, "qty": qty, "received": int(time.time()*1000)}
        if status != "LIVE_SENT" and HEDGE_ON_FAIL:
            # naive hedge attempt: if leg1 executed, try to neutralize position
            try:
                hedge = await adapter.place_order(data["symbol"], "sell", qty=qty, order_type="market")
                details["hedge"] = hedge
                status = "HEDGED"
            except Exception as e:
                details["hedge_error"] = str(e)
    finally:
        try:
            await r.delete(lock_key)
        except Exception:
            pass

                    status = "LIVE_SENT" if "error" not in both else "TIMEOUT"
                    details = {"exec": both, "qty": qty, "received": int(time.time()*1000)}
                else:
                    status = "DRY_RUN"
                    details = {"executor": "no-op", "received": int(time.time()*1000)}
                async with pool.acquire() as conn:
                    await conn.execute(
                        "INSERT INTO trades_log (id, ts, symbol, buy_venue, sell_venue, gross, status, details) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)",
                        str(uuid.uuid4()), data["ts"], data["symbol"], data["buy_venue"], data["sell_venue"], float(data["gross"]), status, json.dumps(details)
                    )

if __name__ == "__main__":
    asyncio.run(run())
