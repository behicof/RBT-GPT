def route(signal: dict, profile: dict) -> dict:
    """Dynamic offsets based on net spread (bps) and simple fee model.
    Larger safety offset when spread is tight; smaller when spread is wide.
    """

    spread = signal.get("spread_bps", 0)
    fees   = signal.get("fees_bps", 0)
    slip   = signal.get("slippage_bps", 8)
    edge   = spread - fees - slip
    tif    = "IOC"  # CoinEx آداپتور خودش IOC را به type='ioc' نگاشت می‌کند.

    legs = signal.get("legs") or [{"venue":"mexc"},{"venue":"coinex"}]
    venues = {l["venue"] for l in legs}
    if edge >= profile.get("min_net_pnl_bps", 10) and {"mexc","coinex"} <= venues:
        # compute net spread (bps)
spread_bps = max(0.0, float(spread) * 100.0) * 100  # percent→bps if needed; ensure bps scale
# assume combined fees ~6 bps (demo); make it conservative
fees_bps = float(profile.get("fees_bps", 6.0))
# desired safety margin grows when net spread is small
# e.g., if spread_bps=20, margin≈(10 - 20)/2 -> clamped
margin = max(4.0, min(20.0, (10.0 - spread_bps) / 2.0 * -1 if spread_bps < 10 else 6.0))
# final offsets
off1 = margin
off2 = margin + 3.0
tif = "IOC" if spread_bps > 100 else "GTC"
return {
    "pair": signal["pair"],
    "qty": qty,
    "buy": signal["buy"],
    "sell": signal["sell"],
    "tif_buy": tif,
    "tif_sell": tif,
    "offset_bps": {"leg1": off1, "leg2": off2},
    "fees_bps": fees_bps,
    "spread_bps": spread_bps
}}
    # compute net spread (bps)
spread_bps = max(0.0, float(spread) * 100.0) * 100  # percent→bps if needed; ensure bps scale
# assume combined fees ~6 bps (demo); make it conservative
fees_bps = float(profile.get("fees_bps", 6.0))
# desired safety margin grows when net spread is small
# e.g., if spread_bps=20, margin≈(10 - 20)/2 -> clamped
margin = max(4.0, min(20.0, (10.0 - spread_bps) / 2.0 * -1 if spread_bps < 10 else 6.0))
# final offsets
off1 = margin
off2 = margin + 3.0
tif = "IOC" if spread_bps > 100 else "GTC"
return {
    "pair": signal["pair"],
    "qty": qty,
    "buy": signal["buy"],
    "sell": signal["sell"],
    "tif_buy": tif,
    "tif_sell": tif,
    "offset_bps": {"leg1": off1, "leg2": off2},
    "fees_bps": fees_bps,
    "spread_bps": spread_bps
}}
