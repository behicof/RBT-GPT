import os, asyncio, json, time, math
import redis.asyncio as aioredis
import yaml
import numpy as np

REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
EXCH_CFG = os.getenv("EXCH_CFG", "./configs/markets.yaml")
RISK_CFG = os.getenv("RISK_CFG", "./configs/risk.yml")

# r.keys pattern: ob:orderbook:{venue}:{symbol}
# We'll compute simple spreads across venues for the same symbol
async def estimate_best_bid_ask_from_nobitex(ob_json):
    try:
        ob = ob_json["data"]["orderbook"]
        # nobitex v3 orderbook returns 'asks' and 'bids' as [[price, qty], ...]
        best_ask = float(ob["asks"][0][0]) if ob["asks"] else math.inf
        best_bid = float(ob["bids"][0][0]) if ob["bids"] else 0.0
        return best_bid, best_ask
    except Exception:
        return 0.0, math.inf

async def run():
    r = aioredis.from_url(REDIS_URL, decode_responses=True)
    with open(EXCH_CFG, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    with open(RISK_CFG, "r", encoding="utf-8") as f:
        risk = yaml.safe_load(f)
    thr = cfg["thresholds"]
    min_net = float(thr["min_net_pnl"])

    while True:
        # discover all orderbook keys
        keys = await r.keys("ob:orderbook:*")
        # group by symbol: { "BASE_QUOTE": {venue: ob_json} }
        buckets = {}
        for k in keys:
            raw = await r.get(k)
            if not raw:
                continue
            ob = json.loads(raw)
            # parse chan name "ob:orderbook:{venue}:{symbol}"
            parts = k.split(":")
            venue = parts[2]
            symbol = parts[3]
            buckets.setdefault(symbol, {})[venue] = ob

        now_ms = int(time.time()*1000)
        for symbol, by_venue in buckets.items():
            # naive pairwise check among venues we have for this symbol
            venues = list(by_venue.keys())
            for i in range(len(venues)):
                for j in range(i+1, len(venues)):
                    v1, v2 = venues[i], venues[j]
                    b1, a1 = await estimate_best_bid_ask_from_nobitex(by_venue[v1])
                    b2, a2 = await estimate_best_bid_ask_from_nobitex(by_venue[v2])

                    # arb: buy at cheaper ask, sell at higher bid
                    # choose path1: buy v1 (a1) sell v2 (b2)
                    if a1 < math.inf and b2 > 0:
                        gross = (b2 - a1) / a1
                        if gross >= min_net:
                            signal = {
                                "ts": now_ms,
                                "symbol": symbol.replace("_","/"),
                                "buy_venue": v1,
                                "sell_venue": v2,
                                "gross": gross,
                                "note": "dry-run signal; fees/slippage not included"
                            }
                            await r.xadd("signals", {"data": json.dumps(signal)},
                                         maxlen=1000, approximate=True)
                    # path2: buy v2 (a2) sell v1 (b1)
                    if a2 < math.inf and b1 > 0:
                        gross = (b1 - a2) / a2
                        if gross >= min_net:
                            signal = {
                                "ts": now_ms,
                                "symbol": symbol.replace("_","/"),
                                "buy_venue": v2,
                                "sell_venue": v1,
                                "gross": gross,
                                "note": "dry-run signal; fees/slippage not included"
                            }
                            await r.xadd("signals", {"data": json.dumps(signal)},
                                         maxlen=1000, approximate=True)

        await asyncio.sleep(0.5)

if __name__ == "__main__":
    asyncio.run(run())
