import os, asyncio, aiohttp, json, time
import redis.asyncio as aioredis
import yaml

REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
EXCH_CFG = os.getenv("EXCH_CFG", "./configs/markets.yaml")

PUBLISH_CHANNEL_FMT = "orderbook:{venue}:{symbol}"

async def fetch_nobitex_orderbook(session, base, quote):
    # Public orderbook (depth 5) per market, documented on apiv2
    url = f"https://apiv2.nobitex.ir/v3/orderbook/{base}{quote}"
    async with session.get(url, timeout=3) as r:
        r.raise_for_status()
        return await r.json()

async def run():
    r = aioredis.from_url(REDIS_URL, decode_responses=True)
    with open(EXCH_CFG, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    symbols = cfg.get("symbols", [])
    venues = cfg.get("exchanges", {})
    # Only nobitex public collector as a starter (others are placeholders)
    target_symbols = [(s["base"], s["quote"]) for s in symbols if "nobitex" in s["venues"]]

    async with aiohttp.ClientSession() as session:
        while True:
            t0 = time.time()
            for base, quote in target_symbols:
                try:
                    data = await fetch_nobitex_orderbook(session, base.lower(), quote.lower())
                    payload = {
                        "venue": "nobitex",
                        "symbol": f"{base}/{quote}",
                        "ts": int(time.time()*1000),
                        "data": data,
                    }
                    chan = PUBLISH_CHANNEL_FMT.format(venue="nobitex", symbol=f"{base}_{quote}")
                    await r.publish(chan, json.dumps(payload))
                    await r.set(f"ob:{chan}", json.dumps(payload), ex=3)
                except Exception as e:
                    # simple error log
                    await r.lpush("logs:collector", f"{int(time.time())} nobitex {base}/{quote} ERR {e}")
            # loop pacing
            dt = time.time() - t0
            await asyncio.sleep(max(0.5, 1.0 - dt))

if __name__ == "__main__":
    asyncio.run(run())
