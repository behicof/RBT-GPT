import os, asyncio, json
from fastapi import FastAPI
from psycopg_pool import ConnectionPool
import psycopg
import psycopg
import psycopg_pool, Body
import redis.asyncio as aioredis
import asyncpg
from pydantic import BaseModel
from typing import List, Dict, Any

REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
PG_URL = os.getenv("PG_URL", "postgresql://postgres:arbpass@localhost:5432/arbdb")

app = FastAPI(title="Arb VPS API", version="1.0")

@app.on_event("startup")
async def startup():
    app.state.redis = aioredis.from_url(REDIS_URL, decode_responses=True)
    app.state.pool = await asyncpg.create_pool(PG_URL, min_size=1, max_size=3)

@app.on_event("shutdown")
async def shutdown():
    await app.state.redis.close()
    await app.state.pool.close()

@app.get("/health")
async def health():
    return {"ok": True}

@app.get("/signals")
async def get_signals(limit: int = 50):
    # read latest N items from Redis stream (approximate by xrange)
    r = app.state.redis
    # fetch last items by reading from end; there is no direct reverse XREAD in redis-py, so we keep it simple:
    items = await r.xrevrange("signals", count=limit)
    out = []
    for entry_id, kv in items:
        out.append({"id": entry_id, **json.loads(kv["data"])})
    return out

@app.get("/trades")
async def trades(limit: int = 50):
    async with app.state.pool.acquire() as conn:
        rows = await conn.fetch("SELECT * FROM trades_log ORDER BY ts DESC LIMIT $1", limit)
        return [dict(r) for r in rows]


from prometheus_client import Gauge, generate_latest, CONTENT_TYPE_LATEST
from fastapi.responses import Response

signals_len_g = Gauge("arb_signals_stream_length", "Current Redis stream length for signals")
trades_total_g = Gauge("arb_trades_total", "Total trades logged (rows in trades_log)")

@app.on_event("startup")
async def metrics_loop():
    async def _loop():
        while True:
            try:
                # Signals length
                try:
                    info = await app.state.redis.xinfo_stream("signals")
                    signals_len_g.set(info.get("length", 0))
                except Exception:
                    signals_len_g.set(0)
                # Trades total
                async with app.state.pool.acquire() as conn:
                    row = await conn.fetchrow("SELECT COUNT(*) AS c FROM trades_log")
                    trades_total_g.set(row["c"] if row else 0)
            except Exception:
                pass
            await asyncio.sleep(2)
    app.state.metrics_task = asyncio.create_task(_loop())

@app.get("/metrics")
async def metrics():
    data = generate_latest()
    return Response(content=data, media_type=CONTENT_TYPE_LATEST)


@app.post("/execute")
async def execute(payload: dict = Body(...)):
    """Publish a manual execution signal to Redis for testing.
    Example payload:
      { "pair": "USDT-IRT", "buy": 60000, "sell": 60200, "spread": 1.2 }
    """
    global R
    pair = (payload.get("pair") or payload.get("symbol") or "USDT-IRT")
    chan = f"sig:{pair}"
    import json, time
    payload.setdefault("ts", time.time())
    await R.publish(chan, json.dumps(payload))
    return {"ok": True, "published": chan}


from typing import List, Literal, Optional

class Leg(BaseModel):
    venue: Literal["paper","nobitex","nobitex_v2","mexc","coinex"]
    side: Literal["buy","sell"]
    price: Optional[float] = None
    tif: Optional[str] = "IOC"

class DualExec(BaseModel):
    symbol: str
    qty: float
    legs: List[Leg]
    offset_bps: Optional[float] = 8.0

@app.post("/execute/dual")
async def execute_dual(req: DualExec, x_api_key: str | None = Header(default=None)):
    if R is None:
        raise HTTPException(status_code=503, detail="Redis not ready")
    if len(req.legs) != 2:
        raise HTTPException(status_code=400, detail="legs must have exactly 2 items")
    _auth_guard(x_api_key); _rate_limit(); ch = f"sig:{req.symbol}"
    payload = req.model_dump()
    payload["type"] = "DUAL"
    await R.publish(ch, orjson.dumps(payload).decode("utf-8") if "orjson" in globals() else json.dumps(payload))
    REQS.inc()
    return {"ok": True, "published": ch, "payload": payload}

from fastapi import Header, Request
import time
API_KEY = os.getenv("EXEC_API_KEY", "")

# very simple in-memory rate limiter (global)
_last_ts = 0.0
_min_interval = float(os.getenv("API_MIN_INTERVAL_SEC", "0.1"))

def _auth_guard(x_api_key: str | None):
    if API_KEY and (x_api_key or "") != API_KEY:
        raise HTTPException(status_code=401, detail="unauthorized")

def _rate_limit():
    global _last_ts
    now = time.time()
    if now - _last_ts < _min_interval:
        raise HTTPException(status_code=429, detail="too many requests")
    _last_ts = now

from fastapi import Query
from fastapi.responses import StreamingResponse

@app.get("/trades")
async def list_trades(limit: int = Query(default=50, ge=1, le=1000)):
    if PG_POOL is None:
        return {"rows": []}
    def _fetch():
        with PG_POOL.connection() as conn, conn.cursor() as cur:
            cur.execute("SELECT id,oid,pair,qty,buy,sell,est_pnl,ok,ts,legs FROM trades ORDER BY ts DESC LIMIT %s", (limit,))
            rows = cur.fetchall()
            cols = [d[0] for d in cur.description]
            return [dict(zip(cols, r)) for r in rows]
    rows = await asyncio.to_thread(_fetch)
    return {"rows": rows}

@app.get("/trades.csv")
async def trades_csv(limit: int = Query(default=200, ge=1, le=5000)):
    if PG_POOL is None:
        return Response(content="", media_type="text/csv")
    import csv, io
    def _fetch_csv():
        with PG_POOL.connection() as conn, conn.cursor() as cur:
            cur.execute("SELECT id,oid,pair,qty,buy,sell,est_pnl,ok,ts FROM trades ORDER BY ts DESC LIMIT %s", (limit,))
            rows = cur.fetchall()
            output = io.StringIO()
            w = csv.writer(output)
            w.writerow(["id","oid","pair","qty","buy","sell","est_pnl","ok","ts"])
            for r in rows: w.writerow(r)
            return output.getvalue()
    data = await asyncio.to_thread(_fetch_csv)
    return Response(content=data, media_type="text/csv")
