from services.executor.routing_policy import route

def test_route_basic():
    sig = {"pair":"USDT-IRT","buy":610000,"sell":612500,"spread": (612500-610000)/612500*100}
    prof = {"qty": 100}
    pol = route(sig, prof)
    assert pol["qty"] == 100
    assert "offset_bps" in pol
